import React, { createContext, useState } from 'react';
import axios from 'axios';

// Create the context
export const AuthContext = createContext(null);

// Define the base URL for your API
const API_URL = 'http://localhost:5000/api/auth';

// Create the provider component
export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);

    // --- UPDATED LOGIN FUNCTION ---
    const login = async (email, password) => {
        try {
            // Make a POST request to your backend's /login endpoint
            const res = await axios.post(`${API_URL}/login`, { email, password });

            if (res.data.success) {
                // If login is successful, update the user state
                setUser(res.data.user);
                // You can also save the token to localStorage for persistence
                localStorage.setItem('authToken', res.data.token);
                return { success: true };
            }
        } catch (error) {
            // If there's an error, return the message from the backend
            return { success: false, message: error.response?.data?.message || "Login failed. Please try again." };
        }
    };

    const register = async (formData, userType) => {
        try {
            const endpoint = userType === 'official' ? '/register-official' : '/register-user';
            const res = await axios.post(`${API_URL}${endpoint}`, formData);
            if (res.data.success) {
                return { success: true, message: "Registration successful!" };
            }
        } catch (error) {
            return { success: false, message: error.response?.data?.message || "Registration failed" };
        }
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('authToken');
    };

    return (
        <AuthContext.Provider value={{ user, login, register, logout }}>
            {children}
        </AuthContext.Provider>
    );
};
